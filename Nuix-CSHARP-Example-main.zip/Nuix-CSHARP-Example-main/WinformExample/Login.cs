﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nuix
{
    public partial class Login : Form
    {

      

        static string name = "";
        static string ownerid = "";
        static string secret = "";
        static string version = "1.0";
        
                    /*
            Optional Functions:
            
            NuixAPP.webhook("lfvbBrbFhIr", "?sellerkey=CUqDqlCIgl&type=resethash");
            // send secure request to webhook which is impossible to crack into. the base link set on the website is https://nuix.xyz/api/seller/, which nobody except you can see, so the final request is https://nuix.xyz/api/seller/?sellerkey=key&type=resethash
            
            NuixAPP.download("231696", "C:\\ok.dll"); // download an application file

            MessageBox.Show(NuixAPP.var("123456")); // retrieve application variable
            */
            
                        // Register and Login Functions (still in beta)
            // NuixAPP.register("username", "password", "key");
            //NuixAPP.login("username", "password"); 

        public static api NuixAPP = new api(name, ownerid, secret, version);

        public Login()
        {
            InitializeComponent();
        }

        private void siticoneControlBox1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void siticoneRoundedButton1_Click(object sender, EventArgs e)
        {
            if(NuixAPP.license(key.Text))
            {
                Main main = new Main();
                main.Show();
                this.Hide();
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {
            NuixAPP.init();
        }
    }
}
